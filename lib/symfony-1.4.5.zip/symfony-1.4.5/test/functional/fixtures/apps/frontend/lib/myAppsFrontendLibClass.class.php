<?php

class myAppsFrontendLibClass
{
  static public function ping()
  {
    return 'pong';
  }
}
