<?php include_partial('format/js_header') ?>

This is a js file
