<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');

$t = new lime_test(1);

$t->pass('this is ok');
